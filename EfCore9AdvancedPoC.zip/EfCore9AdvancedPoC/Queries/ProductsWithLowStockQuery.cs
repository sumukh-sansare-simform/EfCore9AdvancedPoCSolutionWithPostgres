using EfCore9AdvancedPoC.Data;
using EfCore9AdvancedPoC.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EfCore9AdvancedPoC.Queries
{
    public class ProductsWithLowStockQuery
    {
        private readonly AppDbContext _context;

        public ProductsWithLowStockQuery(AppDbContext context)
        {
            _context = context;
        }

        public async Task<List<Product>> ExecuteAsync(int threshold = 10)
        {
            return await _context.Products
                .Where(p => p.Quantity < threshold)
                .OrderBy(p => p.Quantity)
                .ToListAsync();
        }
    }
}
