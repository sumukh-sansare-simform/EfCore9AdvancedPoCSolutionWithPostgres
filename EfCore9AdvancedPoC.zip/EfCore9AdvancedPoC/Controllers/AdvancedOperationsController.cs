using EfCore9AdvancedPoC.Data;
using EfCore9AdvancedPoC.Models;
using EfCore9AdvancedPoC.Models.Json;
using EfCore9AdvancedPoC.Models.Inheritance;
using EfCore9AdvancedPoC.Models.Relationships;
using EfCore9AdvancedPoC.Queries;
using EfCore9AdvancedPoC.Repositories;
using EfCore9AdvancedPoC.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EfCore9AdvancedPoC.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AdvancedOperationsController : ControllerBase
    {
        private readonly BulkOperationService _bulkService;
        private readonly IProductRepository _productRepository;
        private readonly ProductsWithLowStockQuery _lowStockQuery;

        public AdvancedOperationsController(
            BulkOperationService bulkService,
            IProductRepository productRepository,
            ProductsWithLowStockQuery lowStockQuery)
        {
            _bulkService = bulkService;
            _productRepository = productRepository;
            _lowStockQuery = lowStockQuery;
        }

        [HttpGet("health-check")]
        public async Task<IActionResult> CheckHealth()
        {
            var isHealthy = await _bulkService.CheckDatabaseHealthAsync();
            return Ok(new { Status = isHealthy ? "Healthy" : "Unhealthy" });
        }

        [HttpGet("product-details")]
        public async Task<IActionResult> GetProductsWithDetails(
            [FromQuery] bool includeInventory = false,
            [FromQuery] bool includeSalesHistory = false)
        {
            var products = await _bulkService.GetProductsWithFullDetailsAsync(
                includeInventory, includeSalesHistory);

            // Format products to display PostgreSQL infinity value correctly
            var formattedProducts = products.Select(p => new
            {
                p.Id,
                p.Name,
                p.Price,
                p.Quantity,
                p.CreatedAt,
                p.UpdatedAt,
                ValidFrom = p.ValidFrom,
                // Format ValidTo to show "infinity" instead of DateTime.MaxValue
                ValidTo = p.ValidTo >= DateTime.MaxValue.AddDays(-1) ? "infinity" : p.ValidTo,
                ProductDetail = includeInventory ? p.ProductDetail : null,
                Tags = includeSalesHistory ? p.Tags : null
            }).ToList();

            return Ok(new
            {
                TotalCount = products.Count,
                Products = formattedProducts
            });
        }

        [HttpGet("products/{page}")]
        public async Task<IActionResult> GetPaginatedProducts(int page = 1, [FromQuery] int pageSize = 10)
        {
            var result = await _bulkService.GetPaginatedProductsAsync(page, pageSize);
            
            return Ok(new {
                Page = page,
                PageSize = pageSize,
                TotalItems = result.TotalCount,
                TotalPages = (int)Math.Ceiling(result.TotalCount / (double)pageSize),
                Items = result.Items
            });
        }

        [HttpPost("batch-inventory-update")]
        public async Task<IActionResult> UpdateInventoryInBatch([FromBody] Dictionary<int, int> inventoryChanges)
        {
            if (inventoryChanges == null || !inventoryChanges.Any())
            {
                return BadRequest("No inventory changes provided");
            }
            
            var updatedCount = await _bulkService.BatchUpdateProductInventoryAsync(inventoryChanges);
            
            return Ok(new {
                UpdatedProducts = updatedCount,
                Message = $"Successfully updated {updatedCount} products"
            });
        }

        [HttpGet("low-stock")]
        public async Task<IActionResult> GetLowStockProducts([FromQuery] int threshold = 10)
        {
            var products = await _lowStockQuery.ExecuteAsync(threshold);
            
            return Ok(new {
                ThresholdLevel = threshold,
                ProductsCount = products.Count,
                Products = products
            });
        }

        [HttpPost("apply-migrations")]
        public async Task<IActionResult> ApplyMigrations()
        {
            var success = await _bulkService.ApplyMigrationsAsync();
            
            if (success)
                return Ok(new { Message = "Migrations applied successfully" });
            else
                return StatusCode(500, new { Error = "Failed to apply migrations" });
        }
        
        // Repository pattern demonstration
        [HttpGet("repository/products")]
        public async Task<IActionResult> GetProductsUsingRepository()
        {
            var products = await _productRepository.GetAllAsync();
            return Ok(products);
        }
        
        [HttpGet("repository/products/{id}")]
        public async Task<IActionResult> GetProductByIdUsingRepository(int id)
        {
            var product = await _productRepository.GetByIdAsync(id);
            
            if (product == null)
                return NotFound();
                
            return Ok(product);
        }
        
        [HttpPost("repository/products")]
        public async Task<IActionResult> CreateProductUsingRepository([FromBody] Product product)
        {
            if (product == null)
                return BadRequest();
                
            var result = await _productRepository.AddAsync(product);
            return CreatedAtAction(nameof(GetProductByIdUsingRepository), new { id = result.Id }, result);
        }
        
        [HttpPut("repository/products/{id}")]
        public async Task<IActionResult> UpdateProductUsingRepository(int id, [FromBody] Product product)
        {
            if (product == null || id != product.Id)
                return BadRequest();
                
            if (!await _productRepository.ExistsAsync(id))
                return NotFound();
                
            await _productRepository.UpdateAsync(product);
            return NoContent();
        }
        
        [HttpDelete("repository/products/{id}")]
        public async Task<IActionResult> DeleteProductUsingRepository(int id)
        {
            if (!await _productRepository.ExistsAsync(id))
                return NotFound();
                
            await _productRepository.DeleteAsync(id);
            return NoContent();
        }
    }
}
