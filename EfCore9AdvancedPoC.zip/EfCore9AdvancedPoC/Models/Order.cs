using EfCore9AdvancedPoC.Models.Owned;
using EfCore9AdvancedPoC.Models.Json;
using System;

namespace EfCore9AdvancedPoC.Models
{
    public class Order
    {
        public int Id { get; set; }
        public DateTime OrderedAt { get; set; } = DateTime.UtcNow;
        public OrderDetails Details { get; set; } = new(); // JSON column

        public int UserId { get; set; }
        public User User { get; set; }

        public int ProductId { get; set; }
        public Product Product { get; set; }

        public ShippingAddress ShippingAddress { get; set; } = new();
    }
}
