using System;

namespace EfCore9AdvancedPoC.Models
{
    public class Notification
    {
        public int Id { get; set; }
        public string Message { get; set; }
        public string RecipientEmail { get; set; }
        public bool IsProcessed { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public DateTime? ProcessedAt { get; set; }
    }
}
