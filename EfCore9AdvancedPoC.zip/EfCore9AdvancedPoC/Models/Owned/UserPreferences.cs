﻿using Microsoft.EntityFrameworkCore;

namespace EfCore9AdvancedPoC.Models.Owned
{
    [Owned]
    public class UserPreferences
    {
        public string Theme { get; set; }
        public bool ReceiveNewsletter { get; set; }
    }

}
