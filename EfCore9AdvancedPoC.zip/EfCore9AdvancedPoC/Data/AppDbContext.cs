using EfCore9AdvancedPoC.Models;
using EfCore9AdvancedPoC.Models.Inheritance;
using EfCore9AdvancedPoC.Models.Relationships;
using EfCore9AdvancedPoC.Interceptors;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.DataEncryption;
using Microsoft.EntityFrameworkCore.DataEncryption.Providers;
using System.Text;
using Npgsql;

namespace EfCore9AdvancedPoC.Data
{
    public class AppDbContext : DbContext
    {
        private readonly AuditInterceptor _auditInterceptor;
        private readonly IEncryptionProvider _encryptionProvider;

        public DbSet<User> Users => Set<User>();
        public DbSet<Product> Products => Set<Product>();
        public DbSet<Order> Orders => Set<Order>();
        public DbSet<AuditLog> AuditLogs => Set<AuditLog>();

        // TPT inheritance
        public DbSet<BaseEntity> BaseEntities => Set<BaseEntity>();
        public DbSet<CustomerEntity> CustomerEntities => Set<CustomerEntity>();
        public DbSet<EmployeeEntity> EmployeeEntities => Set<EmployeeEntity>();
        private readonly string _connectionString;

        // Many-to-many relationship entities
        public DbSet<Tag> Tags => Set<Tag>();
        public DbSet<ProductTag> ProductTags => Set<ProductTag>();

        // Batch operations demonstration
        public DbSet<Notification> Notifications => Set<Notification>();
        // In AppDbContext.cs, add this DbSet
        public DbSet<Employee> Employees => Set<Employee>();

        public AppDbContext(
      DbContextOptions<AppDbContext> options,
      AuditInterceptor auditInterceptor,
      IConfiguration configuration) : base(options)
        {
            _auditInterceptor = auditInterceptor;
            _connectionString = configuration.GetConnectionString("DefaultConnection");

            // Column encryption setup - fix the key sizes
            // AES requires key size of 16, 24, or 32 bytes and IV size of 16 bytes
            byte[] encryptionKey = Encoding.UTF8.GetBytes("YourEncryptionKey1234567890123456"); // 32 bytes
            byte[] encryptionIV = Encoding.UTF8.GetBytes("YourEncryptIV1234"); // 16 bytes
            _encryptionProvider = new AesProvider(encryptionKey, encryptionIV);
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.AddInterceptors(_auditInterceptor);

            // Enable sensitive data logging for development
            optionsBuilder.EnableSensitiveDataLogging();

            // Add query tags to help identify queries in logs
            optionsBuilder.UseQueryTrackingBehavior(QueryTrackingBehavior.TrackAll);

            // Suppress pending model changes warning
            optionsBuilder.ConfigureWarnings(warnings =>
                warnings.Ignore(Microsoft.EntityFrameworkCore.Diagnostics.RelationalEventId.PendingModelChangesWarning));

            var dataSourceBuilder = new NpgsqlDataSourceBuilder(_connectionString);
            dataSourceBuilder.EnableDynamicJson();
            var dataSource = dataSourceBuilder.Build();
            optionsBuilder.UseNpgsql(dataSource);


            base.OnConfiguring(optionsBuilder);
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // JSON column mapping
            modelBuilder.Entity<User>().OwnsOne(u => u.Preferences).ToJson();
            modelBuilder.Entity<Order>().Property(o => o.Details).HasColumnType("jsonb");

            // Complex Type / Owned Entity
            modelBuilder.Entity<Order>()
    .HasOne(o => o.User)
    .WithMany(u => u.Orders)
    .HasForeignKey(o => o.UserId)
    .IsRequired(false);  // Make the relationship optional

            modelBuilder.Entity<Order>().HasQueryFilter(o => !o.User.IsDeleted);

            // And in OnModelCreating, add:
            modelBuilder.Entity<Employee>()
                .HasOne(e => e.Manager)
                .WithMany(e => e.DirectReports)
                .HasForeignKey(e => e.ManagerId)
                .OnDelete(DeleteBehavior.Restrict);

            // Add this to enable shadow property for products
            modelBuilder.Entity<Product>()
                .Property<DateTime>("LastViewedAt")
                .HasDefaultValue(DateTime.UtcNow);

            // Temporal tables
            modelBuilder.Entity<Product>()
        .ToTable("Products", b => b.IsTemporal(t => {
            t.HasPeriodStart("ValidFrom");
            t.HasPeriodEnd("ValidTo");
            t.UseHistoryTable("ProductsHistory");
        }));
            modelBuilder.Entity<Product>(entity =>
            {
                // Set ValidFrom default constraint
                entity.Property(p => p.ValidFrom)
                    .HasDefaultValueSql("CURRENT_TIMESTAMP")
                    .IsRequired();

                // Set ValidTo default constraint
                entity.Property(p => p.ValidTo)
                    .HasDefaultValueSql("'infinity'::timestamp")
                    .IsRequired();
            });
            modelBuilder.Entity<Product>()
    .HasOne(p => p.ProductDetail)
    .WithOne(pd => pd.Product)
    .HasForeignKey<ProductDetail>(pd => pd.ProductId);

            // Global query filter (soft delete)
            modelBuilder.Entity<User>().HasQueryFilter(u => !u.IsDeleted);

            // TPT (Table-Per-Type) inheritance
            modelBuilder.Entity<BaseEntity>().ToTable("BaseEntities");
            modelBuilder.Entity<CustomerEntity>().ToTable("CustomerEntities");
            modelBuilder.Entity<EmployeeEntity>().ToTable("EmployeeEntities");

            // Configure column encryption
            modelBuilder.Entity<CustomerEntity>()
                .Property(c => c.Email)
                .HasConversion(
                    v => _encryptionProvider.Encrypt(Encoding.UTF8.GetBytes(v ?? string.Empty)),
                    v => Encoding.UTF8.GetString(_encryptionProvider.Decrypt(v) ?? Array.Empty<byte>()));


            // Configure many-to-many relationship
            modelBuilder.Entity<ProductTag>()
                .HasKey(pt => new { pt.ProductId, pt.TagId });

            modelBuilder.Entity<ProductTag>()
                .HasOne(pt => pt.Product)
                .WithMany(p => p.ProductTags)
                .HasForeignKey(pt => pt.ProductId);

            modelBuilder.Entity<ProductTag>()
                .HasOne(pt => pt.Tag)
                .WithMany(t => t.ProductTags)
                .HasForeignKey(pt => pt.TagId);

            // Skip navigation for many-to-many
            modelBuilder.Entity<Product>()
                .HasMany(p => p.Tags)
                .WithMany(t => t.Products)
                .UsingEntity<ProductTag>();

            // Batch configuration
            modelBuilder.Entity<Notification>()
                .HasIndex(n => n.CreatedAt)
                .HasFilter("\"IsProcessed\" = false");

            // Table splitting example
    modelBuilder.Entity<ProductDetail>()
        .HasKey(pd => pd.ProductId);
            modelBuilder.Entity<Product>()
                .HasOne(p => p.ProductDetail)
                .WithOne(pd => pd.Product)
                .HasForeignKey<ProductDetail>(pd => pd.ProductId);

            modelBuilder.Entity<Product>()
                .Navigation(p => p.ProductDetail)
                .IsRequired();

            base.OnModelCreating(modelBuilder);
        }
    }
}
