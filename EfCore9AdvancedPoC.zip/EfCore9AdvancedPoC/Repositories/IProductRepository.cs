using EfCore9AdvancedPoC.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace EfCore9AdvancedPoC.Repositories
{
    public interface IProductRepository
    {
        Task<List<Product>> GetAllAsync();
        Task<Product> GetByIdAsync(int id);
        Task<List<Product>> GetByIdsAsync(IEnumerable<int> ids);
        Task<Product> AddAsync(Product product);
        Task<int> UpdateAsync(Product product);
        Task<int> DeleteAsync(int id);
        Task<bool> ExistsAsync(int id);
    }
}
