using EfCore9AdvancedPoC.Data;
using EfCore9AdvancedPoC.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EfCore9AdvancedPoC.Repositories
{
    public class ProductRepository : IProductRepository
    {
        private readonly AppDbContext _context;
        
        public ProductRepository(AppDbContext context)
        {
            _context = context;
        }
        
        public async Task<List<Product>> GetAllAsync() => 
            await _context.Products.ToListAsync();
            
        public async Task<Product> GetByIdAsync(int id) => 
            await _context.Products.FindAsync(id);
            
        public async Task<List<Product>> GetByIdsAsync(IEnumerable<int> ids) => 
            await _context.Products.Where(p => ids.Contains(p.Id)).ToListAsync();
            
        public async Task<Product> AddAsync(Product product)
        {
            await _context.Products.AddAsync(product);
            await _context.SaveChangesAsync();
            return product;
        }
        
        public async Task<int> UpdateAsync(Product product)
        {
            _context.Products.Update(product);
            return await _context.SaveChangesAsync();
        }
        
        public async Task<int> DeleteAsync(int id)
        {
            var product = await GetByIdAsync(id);
            if (product == null) return 0;
            
            _context.Products.Remove(product);
            return await _context.SaveChangesAsync();
        }
        
        public async Task<bool> ExistsAsync(int id) => 
            await _context.Products.AnyAsync(p => p.Id == id);
    }
}
